package io.bootify.my_app.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
public class TimeFreq11814 {

    @Id
    @Column(nullable = false, updatable = false, length = 2)
    private String timeFreqCd;

    @Column(nullable = false, length = 20)
    private String timeFreqDesc;

    @Column(nullable = false)
    private OffsetDateTime creUt;

    @Column(nullable = false, length = 10)
    private String creUidCd;

    @Column(nullable = false, length = 8)
    private String crePgmNa;

    @Column(nullable = false)
    private OffsetDateTime revsnUt;

    @Column(nullable = false, length = 10)
    private String revsnUidCd;

    @Column(nullable = false, length = 8)
    private String revsnPgmNa;

}
