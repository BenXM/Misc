package io.bootify.my_app.repos;

import io.bootify.my_app.domain.RmdPayoutElectType15040;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RmdPayoutElectType15040Repository extends JpaRepository<RmdPayoutElectType15040, String> {
}
