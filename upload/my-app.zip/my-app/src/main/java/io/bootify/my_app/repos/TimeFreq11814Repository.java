package io.bootify.my_app.repos;

import io.bootify.my_app.domain.TimeFreq11814;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TimeFreq11814Repository extends JpaRepository<TimeFreq11814, String> {
}
