package io.bootify.my_app.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;


@Entity
@Getter
@Setter
public class RmdRecurMthdType15036 {

    @Id
    @Column(nullable = false, updatable = false, length = 2)
    private String rmdRecurMthdTyCd;

    @Column(nullable = false, length = 30)
    private String rmdRecurMthdShrtDesc;

    @Column(nullable = false, length = 80)
    private String rmdRecurMthdDesc;

    @Column(nullable = false)
    private OffsetDateTime creTs;

    @Column(nullable = false, length = 8)
    private String crePgmNa;

    @Column(nullable = false, length = 11)
    private String creUidCd;

    @Column(nullable = false)
    private OffsetDateTime revsnTs;

    @Column(nullable = false, length = 8)
    private String revsnPgmNa;

    @Column(nullable = false, length = 11)
    private String revsnUidCd;

}
