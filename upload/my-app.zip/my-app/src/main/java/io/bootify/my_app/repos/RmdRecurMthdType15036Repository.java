package io.bootify.my_app.repos;

import io.bootify.my_app.domain.RmdRecurMthdType15036;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RmdRecurMthdType15036Repository extends JpaRepository<RmdRecurMthdType15036, String> {
}
