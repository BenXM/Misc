package io.bootify.my_app.repos;

import io.bootify.my_app.domain.RmdEntyType15038;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RmdEntyType15038Repository extends JpaRepository<RmdEntyType15038, String> {
}
